<?php
ob_start();
session_start();
?>

<meta charset="utf-8">
<?php

$title = $_GET["title"];
$Name = $_GET["aName"];
$email = $_GET["aEmail"];
$summary = $_GET["summary"];

echo "題目：";
echo $title;
echo "<br/>作者姓名:";
echo $Name;
echo "<br/>email:";
echo $email;
echo "<br/>內容";
echo $summary;



     echo "<br/><a href='logout.php'>登出</a>";
?>