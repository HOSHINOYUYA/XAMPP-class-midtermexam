<html>
    <?php
    include("setting.inc");
    ?>
    <head>
        <meta charset = "utf-8">
    </head>
    <body>
        <b><font size = "8">Author您好, 歡迎進入論文投稿網頁</font></b>
        <br/>
        <form action = "showpaper.php" method = "get">
        論文標題:<br/>
        <input type="text" name="title"><br/>
        作者姓名:<input tyep="text" name="aName"><br/>
        作者Email:<input type="text" name="aEmail">
        <br/>
        論文摘要:
        <textarea name="summary" value="" rows="20" cols="50">
        </textarea>
        <br/>
        <input type="submit" value="提交">
        <br/>
        <?php 
         echo "<a href='logout.php'>登出</a>";
        ?>
        </form>
    
    </body>
</html>