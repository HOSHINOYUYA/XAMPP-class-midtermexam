<html>
    <?php
    include("setting.inc");
    ?>
    <head>
    <meta charset="utf8">
    </head>

    <body>
        <form action = "check.php" method = "get">
        <b><font size="16"> 高大資管論文投稿系統</font></b>
        <br/>
        請選擇你的角色:
        <select name = "role">
        <option value = "Chair">Chair
        <option value = "Reviewer">Reviewer
        <option value = "Author">Author
        </select>  
        <br/>
        帳號:<input type="text" name="uName"><br/>
        密碼:<input type="password" name="uPWD" required><br/>
        <input type="submit" value="提交">
        <form>   
    </body>
</html>