<?php
    include("setting.inc");
?>
<html>
    <head>
        <meta charset= "utf-8">
    </head>
    <b><font size="10">使用者, 歡迎進入Chair的網頁</font></b>
    <br/>
</html>
<?php 
 echo "<a href='logout.php'>登出</a>";
?>