<html>
    <?php
    include("setting.inc");
    ?>
    <head>
    <meta charset="utf-8">
    </head>
    <body>
    <b><font size="8"> Reviewer您好, 歡迎進入論文評論網頁</font></b><br/>

    <form action = "showreview.php" method = "get">
    論文評審決定:
    <input type="radio" name="review" value="Accept">Accept
    <input type="radio" name="review" value="Minor Revision">Minor Revision
    <input type="radio" name="review" value="Major Revision">Major Revision
    <input type="radio" name="review" value="Reject">Reject
    <br/>
    論文評論評語:
    <textarea name="sComment" value="" rows="20" cols="50">
    </textarea>
    <br/>
    <input type="submit" value="提交">
    <br/>
    <?php
     echo "<a href='logout.php'>登出</a>";
    ?>
    </form>
    
    </body>
</html>