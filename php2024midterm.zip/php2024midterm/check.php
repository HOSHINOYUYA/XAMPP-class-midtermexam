<?php
ob_start();
session_start();
?>

<meta charset="utf-8">
<?php

$sId1="chair";
$sPwd1="123";

$sId2="reviewer";
$sPwd2="234";

$sId3="author";
$sPwd3="345";

$sRole1="Chair";
$sRole2="Reviewer";
$sRole3="Author";

$uId=$_GET["uName"];
$uPwd=$_GET["uPWD"];
$uRole=$_GET["role"];

if($sId1==$uId && $sPwd1==$uPwd && $sRole1 == $uRole){
    setcookie("userName",$uId,$date);
    $_SESSION["check"]="Yes";
    header("Location:chair.php");
}else if($sId2==$uId && $sPwd2==$uPwd && $sRole2 == $uRole){
    setcookie("userName",$uId,$date);
    $_SESSION["check"]="Yes";
    header("Location:reviewer.php");
}else if($sId3==$uId && $sPwd3==$uPwd && $sRole3 == $uRole){
    setcookie("userName",$uId,$date);
    $_SESSION["check"]="Yes";
    header("Location:author.php");
}else{
    $_SESSION["check"]="No";
    header("Location:fail.php");
}
?>