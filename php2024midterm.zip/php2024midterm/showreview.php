<?php
ob_start();
session_start();
?>

<meta charset="utf-8">
<?php

$Comment = $_GET["sComment"];
$Review = $_GET["review"];
echo "論文評審:";
echo $Review;
echo "<br/>內容:";
echo $Comment;

echo "<br/><a href='logout.php'>登出</a>";
?>